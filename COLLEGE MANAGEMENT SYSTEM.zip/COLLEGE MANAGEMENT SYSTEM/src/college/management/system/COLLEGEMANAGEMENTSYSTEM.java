
package college.management.system;


public class COLLEGEMANAGEMENTSYSTEM {

    
            public static void main(String[] args) {
        
    }
    
}


